const mongoose = require('mongoose');

/* TravelerInfo */
const travelerInfoSchema = new mongoose.Schema({
  origin: String,
  destination: String,
  departing_date: Date,
  returning_date: Date
});

/* TripInfo */
const tripInfoSchema = new mongoose.Schema({
  companionNum: {
    type: Number,
    default: 1
  }
});

/* FlightInfo */
const flightInfoSchema = new mongoose.Schema({
  name: String,
  seatClass: String,
  price: Number
});

/* HotelInfo */
const hotelInfoSchema = new mongoose.Schema({
  name: String,
  star: Number,
  location: String,
  roomsRequested: Number,
  price: Number
});

/* CruiseInfo */
const cruiseInfoSchema = new mongoose.Schema({
  name: String,
  cabinType: String,
  price: Number
});

/* Itinerary */
const itinerarySchema = new mongoose.Schema({

  userEmail: {
    type: String,
    required: true
  },

  status: {
  type: String,
  enum: ['Pending', 'Confirmed'],
  default: 'Pending'
  },

  totalPrice: {
    type: Number,
    default: 0
  },

  totalMiles: {
    type: Number,
    default: 0
  },

  stopover: {
    type: String,
    default: ''
  },

  travelerInfo: travelerInfoSchema,

  tripInfo: tripInfoSchema,

  flightInfo: flightInfoSchema,

  hotelInfo: hotelInfoSchema,

  cruiseInfo: cruiseInfoSchema,

  createdOn: {
    type: Date,
    default: Date.now
  }

});

module.exports = mongoose.model(
  'itineraries',
  itinerarySchema
);