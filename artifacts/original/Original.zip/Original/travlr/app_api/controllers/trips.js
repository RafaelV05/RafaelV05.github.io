const mongoose = require('mongoose');
require('../models/travlr'); // register the model
const Model = mongoose.model('trips');

// GET: /trips - list all trips
const tripsList = async (req, res) => {
  const q = await Model
    .find({})
    .exec();

  if (!q || q.length === 0) {
    return res
      .status(404)
      .json({ "message": "No trips found" });
  } else {
    return res
      .status(200)
      .json(q);
  }
};

// GET: /trips/:tripCode - find one trip by code
const tripsFindByCode = async (req, res) => {
  const q = await Model
    .findOne({ 'code': req.params.tripCode })
    .exec();

  if (!q) {
    return res
      .status(404)
      .json({ "message": "Trip not found" });
  } else {
    return res
      .status(200)
      .json(q);
  }
};

// POST: /trips - add a new trip
const tripsAddTrip = async (req, res) => {
  const body = req.body;

  const tripObj = {
    code: body.code,
    name: body.name,
    length: body.length,
    start: body.start,
    resort: body.resort,
    perPerson: body.perPerson,
    image: body.image,
    description: body.description
  };

  const q = await Model.create(tripObj);

  if (!q) {
    return res
      .status(400)
      .json({ "message": "Unable to create trip" });
  } else {
    return res
      .status(201)
      .json(q);
  }
};

// PUT: /trips/:tripCode - update a trip
const tripsUpdateTrip = async (req, res) => {
  const q = await Model
    .findOneAndUpdate(
      { 'code': req.params.tripCode },
      {
        code: req.body.code,
        name: req.body.name,
        length: req.body.length,
        start: req.body.start,
        resort: req.body.resort,
        perPerson: req.body.perPerson,
        image: req.body.image,
        description: req.body.description
      },
      { new: true }
    )
    .exec();

  if (!q) {
    return res
      .status(400)
      .json({ "message": "Trip not found" });
  } else {
    return res
      .status(200)
      .json(q);
  }
};

// DELETE: /trips/:tripCode - delete a trip
const tripsDeleteTrip = async (req, res) => {
  const q = await Model
    .findOneAndDelete({ 'code': req.params.tripCode })
    .exec();

  if (!q) {
    return res
      .status(404)
      .json({ "message": "Trip not found" });
  } else {
    return res
      .status(200)
      .json({ "message": "Trip deleted successfully" });
  }
};

module.exports = {
  tripsList,
  tripsFindByCode,
  tripsAddTrip,
  tripsUpdateTrip,
  tripsDeleteTrip
};