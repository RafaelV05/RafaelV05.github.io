const mongoose = require('mongoose');
const Itinerary = mongoose.model('Itinerary');

const itinerary = async (req, res) => {
  try {
    const userEmail = 'testcustomer@gmail.com';

    const itineraries = await Itinerary.find({
      userEmail: userEmail
    }).sort({ createdOn: -1 });

    console.log('Itineraries found:', itineraries);

    res.render('itinerary', {
      title: 'My Itinerary',
      itineraries
    });

  } catch (err) {
    console.log(err);
    res.render('itinerary', {
      title: 'My Itinerary',
      itineraries: []
    });
  }
};

module.exports = { itinerary };