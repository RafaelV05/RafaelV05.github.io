const Itinerary = require('../models/itinerary');
const Trip = require('../models/travlr');

const bookPackage = async (req, res) => {
  try {
    const trip = await Trip.findOne({
      code: req.body.tripCode
    });

    if (!trip) {
      return res.status(404).json({
        message: 'Trip not found'
      });
    }

    const price = parseFloat(
      trip.perPerson.replace(/[^0-9.]/g, '')
    );

    const itinerary = new Itinerary({
      userEmail: req.auth.email,
      status: 'Pending',
      totalPrice: price,

      travelerInfo: {
        origin: 'Salt Lake City',
        destination: trip.name,
        departing_date: new Date(),
        returning_date: new Date()
      },

      tripInfo: {
        companionNum: 1
      },

      hotelInfo: {
        name: trip.resort,
        star: 4,
        location: trip.name,
        roomsRequested: 1,
        price: price
      }
    });

    await itinerary.save();

    res.status(201).json(itinerary);

  } catch (err) {
    res.status(400).json(err);
  }
};

const getItinerary = async (req, res) => {
  try {
    const itineraries = await Itinerary.find({
      userEmail: req.auth.email
    });

    res.status(200).json(itineraries);

  } catch (err) {
    res.status(400).json(err);
  }
};

const removePendingTrip = async (req, res) => {
  try {
    await Itinerary.deleteOne({
      _id: req.params.id,
      userEmail: req.auth.email,
      status: 'Pending'
    });

    res.status(200).json({
      message: 'Pending trip removed'
    });

  } catch (err) {
    res.status(400).json(err);
  }
};

const confirmPendingTrips = async (req, res) => {
  try {
    await Itinerary.updateMany(
      {
        userEmail: req.auth.email,
        status: 'Pending'
      },
      {
        status: 'Confirmed'
      }
    );

    res.status(200).json({
      message: 'Trips confirmed'
    });

  } catch (err) {
    res.status(400).json(err);
  }
};

const getAllBookings = async (req, res) => {
  try {
    if (req.auth.role !== 'admin') {
      return res.sendStatus(403);
    }

    const bookings = await Itinerary.find().sort({
      createdOn: -1
    });

    res.status(200).json(bookings);

  } catch (err) {
    res.status(400).json(err);
  }
};

const deleteBooking = async (req, res) => {
  try {
    if (req.auth.role !== 'admin') {
      return res.sendStatus(403);
    }

    await Itinerary.deleteOne({
      _id: req.params.id
    });

    res.status(200).json({
      message: 'Booking deleted'
    });

  } catch (err) {
    res.status(400).json(err);
  }
};

const updateBookingStatus = async (req, res) => {
  try {
    if (req.auth.role !== 'admin') {
      return res.sendStatus(403);
    }

    await Itinerary.findByIdAndUpdate(
      req.params.id,
      {
        status: req.body.status
      }
    );

    res.status(200).json({
      message: 'Booking updated'
    });

  } catch (err) {
    res.status(400).json(err);
  }
};

module.exports = {
  bookPackage,
  getItinerary,
  removePendingTrip,
  confirmPendingTrips,
  getAllBookings,
  deleteBooking,
  updateBookingStatus
};