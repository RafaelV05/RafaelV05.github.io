const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');

const tripsController = require('../controllers/trips');
const authController = require('../controllers/authentication');
const travelAgent = require('../controllers/travelAgent');

// Method to authenticate JWT
function authenticateJWT(req, res, next) {
  const authHeader = req.headers['authorization'];

  if (authHeader == null) {
    console.log('Auth Header Required but NOT PRESENT!');
    return res.sendStatus(401);
  }

  const headers = authHeader.split(' ');

  if (headers.length < 2) {
    console.log('Not enough tokens in Auth Header: ' + headers.length);
    return res.sendStatus(401);
  }

  const token = headers[1];

  if (token == null) {
    console.log('Null Bearer Token');
    return res.sendStatus(401);
  }

  jwt.verify(token, process.env.JWT_SECRET, (err, verified) => {
    if (err) {
      return res.sendStatus(401);
    }

    req.auth = verified;
    next();
  });
}

router.route('/register').post(authController.register);
router.route('/login').post(authController.login);

router
  .route('/trips')
  .get(tripsController.tripsList)
  .post(authenticateJWT, tripsController.tripsAddTrip);

router
  .route('/trips/:tripCode')
  .get(tripsController.tripsFindByCode)
  .put(authenticateJWT, tripsController.tripsUpdateTrip)
  .delete(authenticateJWT, tripsController.tripsDeleteTrip);

router
  .route('/itinerary/book')
  .post(authenticateJWT, travelAgent.bookPackage);

router
  .route('/itinerary')
  .get(authenticateJWT, travelAgent.getItinerary);

router
  .route('/itinerary/pending/:id')
  .delete(authenticateJWT, travelAgent.removePendingTrip);

router
  .route('/itinerary/confirm')
  .put(authenticateJWT, travelAgent.confirmPendingTrips);

router
  .route('/admin/bookings')
  .get(authenticateJWT, travelAgent.getAllBookings);

router
  .route('/admin/bookings/:id')
  .delete(authenticateJWT, travelAgent.deleteBooking)
  .put(authenticateJWT, travelAgent.updateBookingStatus);

module.exports = router;