require('dotenv').config();
require('./app_api/models/db');

var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var passport = require('passport');
var jwt = require('jsonwebtoken');

require('./app_api/config/passport');

var indexRouter = require('./app_server/routes/index');
var usersRouter = require('./app_server/routes/users');
var travelRouter = require('./app_server/routes/travel');
var apiRouter = require('./app_api/routes/index');
var handlebars = require('hbs');

// DB connection
var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'app_server', 'views'));

// Register handlebars partials directory
handlebars.registerPartials(
  path.join(__dirname, 'app_server/views/partials')
);

app.set('view engine', 'hbs');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use(passport.initialize());

/*
  Make login state available
  to all Handlebars views
*/
app.use((req, res, next) => {
  const token = req.cookies.token;

  res.locals.isLoggedIn = false;
  res.locals.isAdmin = false;
  res.locals.currentUser = null;

  if (token) {
    try {
      const decoded = jwt.verify(
        token,
        process.env.JWT_SECRET
      );

      res.locals.isLoggedIn = true;
      res.locals.currentUser = decoded;
      res.locals.isAdmin = decoded.role === 'admin';

    } catch (err) {
      res.clearCookie('token');
    }
  }

  next();
});

// Enable CORS for API
app.use('/api', (req, res, next) => {
  res.header(
    'Access-Control-Allow-Origin',
    'http://localhost:4200'
  );

  res.header(
    'Access-Control-Allow-Headers',
    'Origin, X-Requested-With, Content-Type, Accept, Authorization'
  );

  res.header(
    'Access-Control-Allow-Methods',
    'GET, POST, PUT, DELETE, OPTIONS'
  );

  next();
});

app.use('/', indexRouter);
app.use('/users', usersRouter);
app.use('/travel', travelRouter);
app.use('/api', apiRouter);

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// unauthorized JWT error handler
app.use((err, req, res, next) => {
  if (err.name === 'UnauthorizedError') {
    return res
      .status(401)
      .json({
        message:
          err.name + ': ' + err.message
      });
  }

  next(err);
});

// error handler
app.use(function(err, req, res, next) {
  res.locals.message = err.message;

  res.locals.error =
    req.app.get('env') === 'development'
      ? err
      : {};

  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;