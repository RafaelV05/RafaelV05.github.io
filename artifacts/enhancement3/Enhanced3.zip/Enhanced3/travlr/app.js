/**
 * Travlr Getaways
 * ---------------------------------------------------------
 * Application Entry Point
 *
 * This file initializes and configures the Express
 * application used by Travlr Getaways.
 *
 * Responsibilities:
 * - Environment configuration
 * - Database initialization
 * - Passport authentication setup
 * - Middleware registration
 * - Route registration
 * - Handlebars configuration
 * - CORS configuration
 * - Global error handling
 */

/* =========================================================
   Environment and Database Configuration
   ========================================================= */

require('dotenv').config();
require('./app_api/models/db');

/* =========================================================
   Core Application Dependencies
   ========================================================= */

var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var passport = require('passport');
var jwt = require('jsonwebtoken');
var handlebars = require('hbs');

/* =========================================================
   Authentication Configuration
   ========================================================= */

require('./app_api/config/passport');

/* =========================================================
   Route Configuration
   ========================================================= */

var indexRouter = require('./app_server/routes/index');
var usersRouter = require('./app_server/routes/users');
var travelRouter = require('./app_server/routes/travel');
var apiRouter = require('./app_api/routes/index');

/* =========================================================
   Express Application Initialization
   ========================================================= */

var app = express();

/* =========================================================
   View Engine Configuration
   ========================================================= */

app.set(
  'views',
  path.join(__dirname, 'app_server', 'views')
);

/**
 * Register reusable Handlebars partial templates.
 */
handlebars.registerPartials(
  path.join(__dirname, 'app_server/views/partials')
);

app.set('view engine', 'hbs');

/* =========================================================
   Global Middleware Configuration
   ========================================================= */

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use(passport.initialize());

/**
 * Authentication Context Middleware
 *
 * Makes login information available to all
 * Handlebars templates.
 *
 * Exposed variables:
 * - isLoggedIn
 * - currentUser
 * - isAdmin
 */
app.use((req, res, next) => {

  // Retrieve JWT token from browser cookie.
  const token = req.cookies.token;

  res.locals.isLoggedIn = false;
  res.locals.isAdmin = false;
  res.locals.currentUser = null;

  if (token) {
    try {

      // Verify JWT and expose user information.
      const decoded = jwt.verify(
        token,
        process.env.JWT_SECRET
      );

      res.locals.isLoggedIn = true;
      res.locals.currentUser = decoded;
      res.locals.isAdmin =
        decoded.role === 'admin';

    } catch (err) {

      // Remove invalid or expired authentication cookie.
      res.clearCookie('token');
    }
  }

  next();
});

/* =========================================================
   API Cross-Origin Resource Sharing (CORS)
   ========================================================= */

/**
 * Allows requests from the Angular development server
 * to access backend API endpoints during development.
 */
app.use('/api', (req, res, next) => {

  res.header(
    'Access-Control-Allow-Origin',
    'http://localhost:4200'
  );

  res.header(
    'Access-Control-Allow-Headers',
    'Origin, X-Requested-With, Content-Type, Accept, Authorization'
  );

  res.header(
    'Access-Control-Allow-Methods',
    'GET, POST, PUT, DELETE, OPTIONS'
  );

  next();
});

/* =========================================================
   Route Registration
   ========================================================= */

app.use('/', indexRouter);
app.use('/users', usersRouter);
app.use('/travel', travelRouter);
app.use('/api', apiRouter);

/* =========================================================
   Application Error Handling
   ========================================================= */

/**
 * Catch unmatched routes and forward them
 * to the global error handler.
 */
app.use(function(req, res, next) {
  next(createError(404));
});

/**
 * Handles JWT authorization failures and
 * returns a standardized response.
 */
app.use((err, req, res, next) => {

  if (err.name === 'UnauthorizedError') {
    return res
      .status(401)
      .json({
        message:
          err.name + ': ' + err.message
      });
  }

  next(err);
});

/**
 * Global application error handler.
 *
 * Displays detailed error information during
 * development and hides implementation details
 * in production environments.
 */
app.use(function(err, req, res, next) {

  res.locals.message = err.message;

  res.locals.error =
    req.app.get('env') === 'development'
      ? err
      : {};

  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;