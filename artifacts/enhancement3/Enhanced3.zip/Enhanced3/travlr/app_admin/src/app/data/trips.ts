export const trips =  [

  {
    "code": "GALR210214",
    "name": "Gale Reef",
    "length": "4 nights / 5 days",
    "start": "2021-02-14T05:00:00Z",
    "resort": "Emerald Bay, 3 stars",
    "perPerson": "799.00",
    "image": "reef1.jpg",
    "description": "<p>Gale Reef Sed et augue lorem. In sit amet placerat arcu. Mauris volutpat ipsum ac justo mollis vel vestibulum orci gravida. Vestibulum sit amet porttitor odio. Nulla facilisi. Fusce at pretium felis.</p><p>Sed consequat libero ut turpis venenatis at aliquam risus semper. Etiam convallis mi vel risus pretium sodales. Etiam nunc lorem ullamcorper vitae laoreet.</p>"
  },
  {
    "code": "DAWS210315",
    "name": "Dawson's Reef",
    "length": "4 nights / 5 days",
    "start": "2021-03-15T05:00:00Z",
    "resort": "Blue Lagoon, 4 stars",
    "perPerson": "1199.00",
    "image": "reef2.jpg",
    "description": "<p>Dawson's Reef Integer magna leo, posuere et dignissim non, laoreet id lectus. Fusce egestas purus sed felis rutrum rhoncus. Aenean et nulla vel arcu pulvinar blandit.</p><p>Donec sed felis risus, at mattis felis. Pellentesque consequat, nisi ut volutpat vestibulum, urna nisi malesuada mi, fermentum imperdiet justo nulla sed dolor.</p>"
  },
  {
    "code": "CLAR210612",
    "name": "Claire's Reef",
    "length": "4 nights / 5 days",
    "start": "2021-06-12T05:00:00Z",
    "resort": "Coral Sands, 5 stars",
    "perPerson": "1999.00",
    "image": "reef3.jpg",
    "description": "<p>Claire's Reef Donec sed felis risus, at mattis felis. Pellentesque consequat, nisi ut volutpat vestibulum, urna nisi malesuada mi, fermentum imperdiet justo nulla sed dolor.</p><p>Nullam at est a mi vestibulum gravida. Praesent fermentum libero at neque blandit et lacinia metus fermentum.</p>"
  }

];