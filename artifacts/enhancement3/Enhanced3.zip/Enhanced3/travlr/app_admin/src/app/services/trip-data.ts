/**
 * Travlr Getaways
 * ---------------------------------------------------------
 * Trip Data Service
 *
 * Provides communication between the Angular admin
 * application and the Express API.
 *
 * Responsibilities:
 * - Retrieve trip data
 * - Create new trips
 * - Update existing trips
 * - Delete trips
 * - Handle user authentication
 *
 * Enhancement Two: Algorithms and Data Structures
 * ---------------------------------------------------------
 * Added support for search, filtering, and sorting by
 * passing query parameters to the backend API.
 *
 * Supported filters:
 * - Search by trip name, resort, or description
 * - Filter by resort
 * - Filter by maximum price
 * - Filter by maximum trip length
 * - Sort by name, price, date, or trip length
 */

import { Inject, Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

import { Trip } from '../models/trip';
import { User } from '../models/user';
import { AuthResponse } from '../models/auth-response';
import { BROWSER_STORAGE } from '../storage';

/**
 * Query options used when retrieving trips.
 *
 * These values are converted into URL parameters
 * and sent to the backend filtering algorithm.
 */
export interface TripQueryOptions {
  search?: string;
  resort?: string;
  maxPrice?: string;
  maxDays?: string;
  sort?: string;
}

@Injectable({
  providedIn: 'root'
})
export class TripDataService {
  private url = 'http://localhost:3000/api/trips';
  baseUrl = 'http://localhost:3000/api';

  constructor(
    private http: HttpClient,
    @Inject(BROWSER_STORAGE) private storage: Storage
  ) {}

  /**
   * If query options are provided, they are converted
   * into URL parameters and used by the backend to
   * search, filter, and sort trip data.
   */

  getTrips(options: TripQueryOptions = {}): Observable<Trip[]> {
    let params = new HttpParams();

    Object.entries(options).forEach(([key, value]) => {
      if (value) {
        params = params.set(key, value);
      }
    });

    return this.http.get<Trip[]>(this.url, { params });
  }

  /**
   * Creates a new travel package.
   */

  addTrip(formData: Trip): Observable<Trip> {
    return this.http.post<Trip>(this.url, formData);
  }

  /**
   * Retrieves a single trip by trip code.
   */

  getTrip(tripCode: string): Observable<Trip[]> {
    return this.http.get<Trip[]>(this.url + '/' + tripCode);
  }

  /**
   * Updates an existing trip.
   */

  updateTrip(formData: Trip): Observable<Trip> {
    return this.http.put<Trip>(this.url + '/' + formData.code, formData);
  }

  /**
   * Deletes a trip using its unique trip code.
   */

  deleteTrip(tripId: string) {
    return this.http.delete(this.baseUrl + '/trips/' + tripId);
  }

  /**
   * Authenticates an existing user.
   */

  login(user: User, passwd: string): Observable<AuthResponse> {
    return this.handleAuthAPICall('login', user, passwd);
  }

  /**
   * Registers a new user account.
   */

  register(user: User, passwd: string): Observable<AuthResponse> {
    return this.handleAuthAPICall('register', user, passwd);
  }

  /**
   * Shared helper method used by login and registration.
   */
  
  handleAuthAPICall(endpoint: string, user: User, passwd: string): Observable<AuthResponse> {
    const formData = {
      name: user.name,
      email: user.email,
      password: passwd
    };

    return this.http.post<AuthResponse>(this.baseUrl + '/' + endpoint, formData);
  }
}