/**
 * Travlr Getaways
 * ---------------------------------------------------------
 * Trip Listing Component
 *
 * Displays travel packages retrieved from the backend API.
 *
 * Enhancement Two: Algorithms and Data Structures
 * ---------------------------------------------------------
 * Adds search, filtering, and sorting controls that send
 * query options to the backend trip-processing algorithm.
 */

import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import { Trip } from '../models/trip';
import { TripDataService, TripQueryOptions } from '../services/trip-data';
import { TripCard } from '../trip-card/trip-card';
import { AuthenticationService } from '../services/authentication';

@Component({
  selector: 'app-trip-listing',
  standalone: true,
  imports: [CommonModule, FormsModule, TripCard],
  templateUrl: './trip-listing.html',
  styleUrl: './trip-listing.css',
  providers: [TripDataService]
})
export class TripListing implements OnInit {

  /** Collection of trips displayed on the page */
  trips: Trip[] = [];

  /** User-facing status message */
  message: string = '';

  /** Search and filter values entered by the user */
  searchText: string = '';
  resortFilter: string = '';
  maxPrice: string = '';
  maxDays: string = '';

  /** Selected sorting option */
  selectedSort: string = 'nameAsc';

  constructor(
    private tripDataService: TripDataService,
    private cdr: ChangeDetectorRef,
    private router: Router,
    private authenticationService: AuthenticationService
  ) {}

  /**
   * Loads trips from the backend using the current
   * search, filter, and sort options.
   */
  private loadTrips(): void {
    const options: TripQueryOptions = {
      search: this.searchText,
      resort: this.resortFilter,
      maxPrice: this.maxPrice,
      maxDays: this.maxDays,
      sort: this.selectedSort
    };

    this.tripDataService.getTrips(options).subscribe({
      next: (value: Trip[]) => {
        this.trips = [...value];

        this.message = value.length > 0
          ? 'There are ' + value.length + ' trips available.'
          : 'No trips matched the current search or filter options.';

        this.cdr.detectChanges();
      },
      error: (error: any) => {
        console.log('Error: ' + error);
        this.message = 'Unable to retrieve trips.';
      }
    });
  }

  /**
   * Applies the current search, filter, and sort options.
   */
  public applyFilters(): void {
    this.loadTrips();
  }

  /**
   * Navigates to the Add Trip page.
   */
  public addTrip(): void {
    this.router.navigate(['add-trip']);
  }

  /**
   * Checks whether a user is currently logged in.
   */
  public isLoggedIn(): boolean {
    return this.authenticationService.isLoggedIn();
  }

  /**
   * Loads trips when the component first opens.
   */
  ngOnInit(): void {
    this.loadTrips();
  }
}