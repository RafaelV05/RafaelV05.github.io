/**
 * Travlr Getaways API Routes
 * ---------------------------------------------------------
 * Defines API endpoints for authentication, trips, customer
 * itineraries, checkout, and administrative booking features.
 *
 * Protected routes use JWT authentication middleware.
 * Admin-only routes also use role-based authorization middleware.
 */

const express = require('express');
const router = express.Router();

const tripsController = require('../controllers/trips');
const authController = require('../controllers/authentication');
const travelAgent = require('../controllers/travelAgent');

const { authenticateJWT } = require('../middleware/auth');
const { authorizeRole } = require('../middleware/authorize');

/* =========================================================
   Authentication Routes
   ========================================================= */

router.route('/register').post(authController.register);
router.route('/login').post(authController.login);

/* =========================================================
   Trip Management Routes
   ========================================================= */

router
  .route('/trips')
  .get(tripsController.tripsList)
  .post(authenticateJWT, tripsController.tripsAddTrip);

router
  .route('/trips/:tripCode')
  .get(tripsController.tripsFindByCode)
  .put(authenticateJWT, tripsController.tripsUpdateTrip)
  .delete(authenticateJWT, tripsController.tripsDeleteTrip);

/* =========================================================
   Customer Itinerary Routes
   ========================================================= */

router
  .route('/itinerary/book')
  .post(authenticateJWT, travelAgent.bookPackage);

router
  .route('/itinerary')
  .get(authenticateJWT, travelAgent.getItinerary);

router
  .route('/itinerary/pending/:id')
  .delete(authenticateJWT, travelAgent.removePendingTrip);

router
  .route('/itinerary/confirm')
  .put(authenticateJWT, travelAgent.confirmPendingTrips);

/* =========================================================
   Admin Booking Routes
   ========================================================= */

router
  .route('/admin/bookings')
  .get(
    authenticateJWT,
    authorizeRole('admin'),
    travelAgent.getAllBookings
  );

router
  .route('/admin/bookings/:id')
  .delete(
    authenticateJWT,
    authorizeRole('admin'),
    travelAgent.deleteBooking
  )
  .put(
    authenticateJWT,
    authorizeRole('admin'),
    travelAgent.updateBookingStatus
  );

module.exports = router;