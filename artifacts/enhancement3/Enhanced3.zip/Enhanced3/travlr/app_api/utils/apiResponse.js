/**
 * API Response Utilities
 *
 * Provides a consistent structure for API error responses. Keeping this logic
 * in one utility file improves maintainability because controllers do not need
 * to repeat the same response formatting logic.
 */

/**
 * Sends a standardized JSON error response.
 *
 * @param {object} res - Express response object.
 * @param {number} statusCode - HTTP status code to return.
 * @param {string} message - User-friendly error message.
 * @param {object|null} details - Optional technical details for debugging.
 */
const sendError = (res, statusCode, message, details = null) => {
  const response = {
    success: false,
    message
  };

  if (details && process.env.NODE_ENV === 'development') {
    response.details = details.message || details;
  }

  return res.status(statusCode).json(response);
};

module.exports = {
  sendError
};
