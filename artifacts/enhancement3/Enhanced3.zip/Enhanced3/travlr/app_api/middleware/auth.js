/**
 * Authentication Middleware
 *
 * Verifies JSON Web Tokens sent through the Authorization header. This separates
 * authentication responsibilities from the route definitions so routes can focus
 * on mapping URLs to controller actions.
 */

const jwt = require('jsonwebtoken');
const { sendError } = require('../utils/apiResponse');

/**
 * Confirms that the request includes a valid Bearer token.
 * If valid, the decoded token payload is attached to req.auth.
 */
const authenticateJWT = (req, res, next) => {
  const authHeader = req.headers.authorization;

  if (!authHeader) {
    return sendError(res, 401, 'Authorization header is required');
  }

  const [scheme, token] = authHeader.split(' ');

  if (scheme !== 'Bearer' || !token) {
    return sendError(res, 401, 'Bearer token is missing or invalid');
  }

  jwt.verify(token, process.env.JWT_SECRET, (err, verified) => {
    if (err) {
      return sendError(res, 401, 'Invalid or expired token');
    }

    req.auth = verified;
    next();
  });
};

module.exports = {
  authenticateJWT
};
