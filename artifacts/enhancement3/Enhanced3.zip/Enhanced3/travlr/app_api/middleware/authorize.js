/**
 * Authorization Middleware
 *
 * Centralizes role-based access control for protected API routes. This avoids
 * repeating admin checks inside multiple controllers and makes permissions
 * easier to audit or update later.
 */

const { sendError } = require('../utils/apiResponse');

/**
 * Allows access only when the authenticated user's role matches one of the
 * accepted roles passed to the middleware.
 *
 */
const authorizeRole = (...acceptedRoles) => {
  return (req, res, next) => {
    if (!req.auth || !acceptedRoles.includes(req.auth.role)) {
      return sendError(res, 403, 'Access denied');
    }

    next();
  };
};

module.exports = {
  authorizeRole
};
