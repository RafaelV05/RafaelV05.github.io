/**
 * Travlr Getaways
 * ---------------------------------------------------------
 * Travel Agent Controller
 *
 * Handles customer booking operations, itinerary retrieval,
 * checkout confirmation, and administrative booking actions.
 *
 * Database Enhancement:
 * - Creates structured itinerary documents in MongoDB
 * - Uses booking status values to manage the reservation workflow
 * - Validates trip data before creating itinerary records
 * - Supports indexed queries by userEmail, status, and createdOn
 */

const Itinerary = require('../models/itinerary');
const Trip = require('../models/travlr');
const { sendError } = require('../utils/apiResponse');

/**
 * Create Pending Itinerary
 *
 * Creates a pending itinerary from a selected travel package.
 * The itinerary is connected to the authenticated customer
 * through the user's email address.
 */
const bookPackage = async (req, res) => {
  try {
    // Validate that a trip code was sent in the request.
    if (!req.body.tripCode) {
      return sendError(res, 400, 'Trip code is required');
    }

    // Find the selected trip using the trip code.
    const trip = await Trip.findOne({
      code: req.body.tripCode
    });

    if (!trip) {
      return sendError(res, 404, 'Trip not found');
    }

    // Convert formatted price string into a usable number.
    const price = parseFloat(
      String(trip.perPerson).replace(/[^0-9.]/g, '')
    );

    // Prevent invalid price data from being stored.
    if (Number.isNaN(price) || price < 0) {
      return sendError(res, 400, 'Invalid trip price');
    }

    // Build a structured itinerary document.
    // New bookings begin as Pending until checkout is completed.
    const itinerary = new Itinerary({
      userEmail: req.auth.email,
      status: 'Pending',
      totalPrice: price,

      travelerInfo: {
        origin: 'Salt Lake City',
        destination: trip.name,
        departing_date: new Date(),
        returning_date: new Date()
      },

      tripInfo: {
        companionNum: 1
      },

      hotelInfo: {
        name: trip.resort,
        star: 4,
        location: trip.name,
        roomsRequested: 1,
        price: price
      }
    });

    // Save the itinerary to MongoDB.
    await itinerary.save();

    res.status(201).json(itinerary);

  } catch (err) {
    sendError(res, 400, 'Unable to book trip', err);
  }
};

/**
 * Get Customer Itinerary
 *
 * Retrieves all itineraries for the authenticated customer.
 * Results are sorted by newest first.
 */
const getItinerary = async (req, res) => {
  try {
    const itineraries = await Itinerary.find({
      userEmail: req.auth.email
    }).sort({
      createdOn: -1
    });

    res.status(200).json(itineraries);

  } catch (err) {
    sendError(res, 400, 'Unable to retrieve itinerary', err);
  }
};

/**
 * Remove Pending Trip
 *
 * Removes a pending trip from the customer's checkout list.
 * Confirmed reservations are protected from this customer action.
 */
const removePendingTrip = async (req, res) => {
  try {
    const result = await Itinerary.deleteOne({
      _id: req.params.id,
      userEmail: req.auth.email,
      status: 'Pending'
    });

    if (result.deletedCount === 0) {
      return sendError(res, 404, 'Pending trip not found');
    }

    res.status(200).json({
      message: 'Pending trip removed'
    });

  } catch (err) {
    sendError(res, 400, 'Unable to remove pending trip', err);
  }
};

/**
 * Confirm Pending Trips
 *
 * Updates all pending trips for the authenticated customer
 * and changes their status to Confirmed during checkout.
 */
const confirmPendingTrips = async (req, res) => {
  try {
    const result = await Itinerary.updateMany(
      {
        userEmail: req.auth.email,
        status: 'Pending'
      },
      {
        status: 'Confirmed'
      }
    );

    res.status(200).json({
      message: 'Trips confirmed',
      modifiedCount: result.modifiedCount
    });

  } catch (err) {
    sendError(res, 400, 'Unable to confirm trips', err);
  }
};

/**
 * Get All Bookings
 *
 * Admin function that retrieves all customer bookings
 * sorted by newest first.
 */
const getAllBookings = async (req, res) => {
  try {
    const bookings = await Itinerary.find().sort({
      createdOn: -1
    });

    res.status(200).json(bookings);

  } catch (err) {
    sendError(res, 400, 'Unable to retrieve bookings', err);
  }
};

/**
 * Delete Booking
 *
 * Admin function that removes a booking from the database.
 */
const deleteBooking = async (req, res) => {
  try {
    const result = await Itinerary.deleteOne({
      _id: req.params.id
    });

    if (result.deletedCount === 0) {
      return sendError(res, 404, 'Booking not found');
    }

    res.status(200).json({
      message: 'Booking deleted'
    });

  } catch (err) {
    sendError(res, 400, 'Unable to delete booking', err);
  }
};

/**
 * Update Booking Status
 *
 * Admin function that updates the status of a selected booking.
 * Status validation is also enforced by the Mongoose schema.
 */
const updateBookingStatus = async (req, res) => {
  try {
    const validStatuses = ['Pending', 'Confirmed', 'Cancelled'];

    if (!validStatuses.includes(req.body.status)) {
      return sendError(res, 400, 'Invalid booking status');
    }

    const booking = await Itinerary.findByIdAndUpdate(
      req.params.id,
      {
        status: req.body.status
      },
      {
        new: true,
        runValidators: true
      }
    );

    if (!booking) {
      return sendError(res, 404, 'Booking not found');
    }

    res.status(200).json({
      message: 'Booking updated',
      booking
    });

  } catch (err) {
    sendError(res, 400, 'Unable to update booking', err);
  }
};

module.exports = {
  bookPackage,
  getItinerary,
  removePendingTrip,
  confirmPendingTrips,
  getAllBookings,
  deleteBooking,
  updateBookingStatus
};