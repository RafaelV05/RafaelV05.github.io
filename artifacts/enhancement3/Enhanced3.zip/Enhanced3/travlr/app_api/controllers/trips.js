/**
 * Travlr Getaways
 * ---------------------------------------------------------
 * Trips Controller
 *
 * Handles CRUD operations for travel packages used by both
 * the customer-facing site and the Angular admin interface.
 *
 * This controller supports:
 * - Retrieving all trips
 * - Retrieving one trip by trip code
 * - Creating new trips
 * - Updating existing trips
 * - Deleting trips
 *
 * Enhancement
 * - Adds search, filtering, and sorting support for trips.
 * - Uses an array of filter functions to process trip data.
 * - Uses reusable sort strategies to organize results.
 */

const mongoose = require('mongoose');
require('../models/travlr');

const Model = mongoose.model('trips');
const { sendError } = require('../utils/apiResponse');

/**
 * Converts price values into numbers.
 * Supports values stored as numbers or strings like "$1,200".
 */
const parsePrice = (price) => {
  if (typeof price === 'number') {
    return price;
  }

  if (!price) {
    return 0;
  }

  return Number(String(price).replace(/[^0-9.]/g, '')) || 0;
};

/**
 * Extracts the number of days from trip length text.
 * Example: "5 days / 4 nights" becomes 5.
 */
const parseTripLength = (length) => {
  if (!length) {
    return 0;
  }

  const match = String(length).match(/\d+/);
  return match ? Number(match[0]) : 0;
};

/**
 * Normalizes text so searches are case-insensitive.
 */
const normalizeText = (value) => {
  return String(value || '').toLowerCase().trim();
};

/**
 * Builds a list of filter functions based on query parameters.
 * Each filter is only added when the user provides that option.
 */
const buildTripFilters = (query) => {
  const filters = [];

  if (query.search) {
    const searchText = normalizeText(query.search);

    filters.push((trip) => {
      const searchableText = normalizeText(
        `${trip.name} ${trip.resort} ${trip.description}`
      );

      return searchableText.includes(searchText);
    });
  }

  if (query.resort) {
    const resortText = normalizeText(query.resort);

    filters.push((trip) => {
      return normalizeText(trip.resort).includes(resortText);
    });
  }

  if (query.maxPrice) {
    const maxPrice = Number(query.maxPrice);

    filters.push((trip) => {
      return parsePrice(trip.perPerson) <= maxPrice;
    });
  }

  if (query.maxDays) {
    const maxDays = Number(query.maxDays);

    filters.push((trip) => {
      return parseTripLength(trip.length) <= maxDays;
    });
  }

  return filters;
};

/**
 * Reusable sorting strategies for trip results.
 */
const sortStrategies = {
  nameAsc: (a, b) => normalizeText(a.name).localeCompare(normalizeText(b.name)),

  nameDesc: (a, b) => normalizeText(b.name).localeCompare(normalizeText(a.name)),

  priceAsc: (a, b) => parsePrice(a.perPerson) - parsePrice(b.perPerson),

  priceDesc: (a, b) => parsePrice(b.perPerson) - parsePrice(a.perPerson),

  dateAsc: (a, b) => new Date(a.start) - new Date(b.start),

  dateDesc: (a, b) => new Date(b.start) - new Date(a.start),

  lengthAsc: (a, b) => parseTripLength(a.length) - parseTripLength(b.length),

  lengthDesc: (a, b) => parseTripLength(b.length) - parseTripLength(a.length)
};

/**
 * GET: /trips
 *
 * Retrieves travel packages from MongoDB.
 * Supports optional search, filtering, and sorting.
 *
 * Example:
 * /api/trips?search=reef&maxPrice=1000&sort=priceAsc
 */
const tripsList = async (req, res) => {
  try {
    const trips = await Model
      .find({})
      .exec();

    if (!trips || trips.length === 0) {
      return sendError(res, 404, 'No trips found');
    }

    const filters = buildTripFilters(req.query);

    let results = filters.reduce(
      (filteredTrips, filterFunction) => filteredTrips.filter(filterFunction),
      trips
    );

    const selectedSort = req.query.sort || 'nameAsc';
    const sortFunction = sortStrategies[selectedSort];

    if (sortFunction) {
      results = [...results].sort(sortFunction);
    }

    return res.status(200).json(results);

  } catch (err) {
    return sendError(res, 500, 'Unable to retrieve trips', err);
  }
};

/**
 * GET: /trips/:tripCode
 *
 * Retrieves one travel package using its unique trip code.
 */
const tripsFindByCode = async (req, res) => {
  try {
    const trip = await Model
      .findOne({ code: req.params.tripCode })
      .exec();

    if (!trip) {
      return sendError(res, 404, 'Trip not found');
    }

    return res.status(200).json(trip);

  } catch (err) {
    return sendError(res, 500, 'Unable to retrieve trip', err);
  }
};

/**
 * POST: /trips
 *
 * Creates a new travel package. This route is protected
 * and intended for authenticated administrative users.
 */
const tripsAddTrip = async (req, res) => {
  try {
    const body = req.body;

    const tripObj = {
      code: body.code,
      name: body.name,
      length: body.length,
      start: body.start,
      resort: body.resort,
      perPerson: body.perPerson,
      image: body.image,
      description: body.description
    };

    const trip = await Model.create(tripObj);

    if (!trip) {
      return sendError(res, 400, 'Unable to create trip');
    }

    return res.status(201).json(trip);

  } catch (err) {
    return sendError(res, 400, 'Unable to create trip', err);
  }
};

/**
 * PUT: /trips/:tripCode
 *
 * Updates an existing travel package by matching its
 * unique trip code.
 */
const tripsUpdateTrip = async (req, res) => {
  try {
    const trip = await Model
      .findOneAndUpdate(
        { code: req.params.tripCode },
        {
          code: req.body.code,
          name: req.body.name,
          length: req.body.length,
          start: req.body.start,
          resort: req.body.resort,
          perPerson: req.body.perPerson,
          image: req.body.image,
          description: req.body.description
        },
        { new: true }
      )
      .exec();

    if (!trip) {
      return sendError(res, 404, 'Trip not found');
    }

    return res.status(200).json(trip);

  } catch (err) {
    return sendError(res, 400, 'Unable to update trip', err);
  }
};

/**
 * DELETE: /trips/:tripCode
 *
 * Deletes a travel package by matching its unique trip code.
 */
const tripsDeleteTrip = async (req, res) => {
  try {
    const trip = await Model
      .findOneAndDelete({ code: req.params.tripCode })
      .exec();

    if (!trip) {
      return sendError(res, 404, 'Trip not found');
    }

    return res.status(200).json({
      message: 'Trip deleted successfully'
    });

  } catch (err) {
    return sendError(res, 400, 'Unable to delete trip', err);
  }
};

module.exports = {
  tripsList,
  tripsFindByCode,
  tripsAddTrip,
  tripsUpdateTrip,
  tripsDeleteTrip
};