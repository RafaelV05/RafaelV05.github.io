/**
 * Travlr Getaways
 * ---------------------------------------------------------
 * Itinerary Controller
 *
 * This controller is responsible for retrieving and displaying
 * itinerary information for a logged-in customer.
 *
 * Current Functionality:
 * - Retrieves all itineraries associated with a user
 * - Sorts itineraries by creation date (newest first)
 * - Passes itinerary data to the itinerary view
 * - Handles database errors gracefully
 *
 * Database Enhancement:
 * - Will support improved itinerary structure
 * - Will support itinerary status tracking
 *   (Pending, Confirmed, Cancelled)
 * - Will utilize indexed fields for faster queries
 * - Will enforce stronger validation rules
 */

const mongoose = require('mongoose');
const Itinerary = mongoose.model('Itinerary');

/**
 * Display Customer Itinerary
 *
 * Retrieves all itineraries associated with the current user
 * and sends the results to the itinerary view.
 *
 * Results are sorted by creation date so the most recent
 * bookings appear first.
 */
const itinerary = async (req, res) => {
  try {

    // Temporary test user.
    // Future enhancement will retrieve the email from
    // the authenticated JWT token/session.
    const userEmail = 'testcustomer@gmail.com';

    // Retrieve itineraries for the specified user.
    // Sort by newest bookings first.
    const itineraries = await Itinerary.find({
      userEmail: userEmail
    }).sort({ createdOn: -1 });

    console.log('Itineraries found:', itineraries);

    // Render itinerary page with retrieved data.
    res.render('itinerary', {
      title: 'My Itinerary',
      itineraries
    });

  } catch (err) {

    // Log database errors for troubleshooting.
    console.error('Error retrieving itineraries:', err);

    // Render page with empty results to prevent application crash.
    res.render('itinerary', {
      title: 'My Itinerary',
      itineraries: []
    });
  }
};

// Export controller function for route usage.
module.exports = { itinerary };