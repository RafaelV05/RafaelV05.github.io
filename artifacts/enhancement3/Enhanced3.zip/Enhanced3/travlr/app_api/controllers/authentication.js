/**
 * Travlr Getaways
 * ---------------------------------------------------------
 * Authentication Controller
 *
 * Handles user registration and login for the Travlr
 * Getaways application. New users are registered as
 * customers by default, while authentication is handled
 * through Passport and JWT tokens.
 */

const passport = require('passport');
const User = require('../models/user');
const { sendError } = require('../utils/apiResponse');

/**
 * Registers a new customer account.
 *
 * Validates that the required fields are present, creates
 * a new user record, hashes the password through the User
 * model, and returns a JWT token after successful registration.
 */
const register = async (req, res) => {
  try {
    if (!req.body.name || !req.body.email || !req.body.password) {
      return sendError(res, 400, 'All fields are required');
    }

    const user = new User({
      name: req.body.name,
      email: req.body.email,
      role: 'customer'
    });

    // Hash and store the password securely before saving.
    user.setPassword(req.body.password);

    await user.save();

    const token = user.generateJWT();

    return res.status(200).json({ token });

  } catch (err) {
    return sendError(res, 400, 'Unable to register user', err);
  }
};

/**
 * Authenticates an existing user.
 *
 * Validates required login fields, checks the submitted
 * credentials through Passport's local strategy, and returns
 * a JWT token when authentication succeeds.
 */
const login = (req, res, next) => {
  if (!req.body.email || !req.body.password) {
    return sendError(res, 400, 'All fields are required');
  }

  passport.authenticate('local', (err, user, info) => {
    if (err) {
      return sendError(res, 404, 'Authentication error', err);
    }

    if (user) {
      const token = user.generateJWT();

      return res.status(200).json({ token });
    }

    return sendError(
      res,
      401,
      info?.message || 'Invalid email or password'
    );
  })(req, res, next);
};

module.exports = {
  register,
  login
};