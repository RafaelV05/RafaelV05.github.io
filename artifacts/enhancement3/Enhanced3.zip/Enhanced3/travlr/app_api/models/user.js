/**
 * Travlr Getaways
 * ---------------------------------------------------------
 * User Model
 *
 * Defines the MongoDB schema for application users and
 * provides methods for password management and JWT
 * authentication.
 *
 * Security Features:
 * - Password hashing using PBKDF2
 * - Unique user accounts
 * - Role-based authorization support
 * - JSON Web Token generation
 */

const mongoose = require('mongoose');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');

/**
 * User Schema
 *
 * Stores customer and administrator account information.
 */
const userSchema = new mongoose.Schema({
  email: {
    type: String,
    unique: true,
    required: true
  },

  name: {
    type: String,
    required: true
  },

  role: {
    type: String,
    enum: ['customer', 'admin'],
    default: 'customer'
  },

  hash: String,
  salt: String
});

/**
 * Generates a secure password hash and salt.
 *
 * Passwords are never stored directly in the database.
 * Instead, a unique salt is generated and combined with
 * the password using PBKDF2 hashing.
 *
 * @param {string} password
 */
userSchema.methods.setPassword = function(password) {

  // Generate a random salt value.
  this.salt = crypto
    .randomBytes(16)
    .toString('hex');

  // Create a password hash using PBKDF2.
  this.hash = crypto
    .pbkdf2Sync(
      password,
      this.salt,
      1000,
      64,
      'sha512'
    )
    .toString('hex');
};

/**
 * Verifies a user password against the stored hash.
 *
 * @param {string} password
 * @returns {boolean}
 */
userSchema.methods.validPassword = function(password) {

  const hash = crypto
    .pbkdf2Sync(
      password,
      this.salt,
      1000,
      64,
      'sha512'
    )
    .toString('hex');

  return this.hash === hash;
};

/**
 * Generates a JSON Web Token (JWT).
 *
 * The token contains user identification and role
 * information used by the authentication middleware.
 *
 * @returns {string}
 */
userSchema.methods.generateJWT = function() {

  return jwt.sign(
    {
      _id: this._id,
      email: this.email,
      name: this.name,
      role: this.role
    },

    process.env.JWT_SECRET,

    {
      expiresIn: '1h'
    }
  );
};

const User = mongoose.model(
  'users',
  userSchema
);

module.exports = User;