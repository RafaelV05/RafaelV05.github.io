/**
 * Travlr Getaways
 * ---------------------------------------------------------
 * Itinerary Database Model
 *
 * Defines the MongoDB/Mongoose schema for customer itinerary
 * and reservation data.
 *
 * Database Enhancement:
 * - Adds stronger validation for required customer and booking data
 * - Uses enum values to control reservation status
 * - Adds default values for safer database records
 * - Adds indexes for fields commonly used in queries
 * - Organizes related booking data into nested schemas
 */

const mongoose = require('mongoose');

/**
 * Traveler Information Schema
 *
 * Stores the basic travel route and travel dates selected
 * by the customer.
 */
const travelerInfoSchema = new mongoose.Schema({
  origin: {
    type: String,
    trim: true,
    default: ''
  },
  destination: {
    type: String,
    trim: true,
    default: ''
  },
  departing_date: Date,
  returning_date: Date
});

/**
 * Trip Information Schema
 *
 * Stores package-level trip details, such as number of travelers.
 */
const tripInfoSchema = new mongoose.Schema({
  companionNum: {
    type: Number,
    default: 1,
    min: 1
  }
});

/**
 * Flight Information Schema
 */
const flightInfoSchema = new mongoose.Schema({
  name: {
    type: String,
    trim: true,
    default: ''
  },
  seatClass: {
    type: String,
    trim: true,
    default: ''
  },
  price: {
    type: Number,
    default: 0,
    min: 0
  }
});

/**
 * Hotel Information Schema
 */
const hotelInfoSchema = new mongoose.Schema({
  name: {
    type: String,
    trim: true,
    default: ''
  },
  star: {
    type: Number,
    default: 0,
    min: 0,
    max: 5
  },
  location: {
    type: String,
    trim: true,
    default: ''
  },
  roomsRequested: {
    type: Number,
    default: 1,
    min: 1
  },
  price: {
    type: Number,
    default: 0,
    min: 0
  }
});

/**
 * Cruise Information Schema
 */
const cruiseInfoSchema = new mongoose.Schema({
  name: {
    type: String,
    trim: true,
    default: ''
  },
  cabinType: {
    type: String,
    trim: true,
    default: ''
  },
  price: {
    type: Number,
    default: 0,
    min: 0
  }
});

/**
 * Main Itinerary Schema
 *
 * Stores one customer itinerary/reservation document.
 * Each document is tied to a user email and can move through
 * the booking workflow using the status field.
 */
const itinerarySchema = new mongoose.Schema({
  userEmail: {
    type: String,
    required: true,
    trim: true,
    lowercase: true,
    index: true
  },

  status: {
    type: String,
    enum: ['Pending', 'Confirmed', 'Cancelled'],
    default: 'Pending',
    index: true
  },

  totalPrice: {
    type: Number,
    default: 0,
    min: 0
  },

  totalMiles: {
    type: Number,
    default: 0,
    min: 0
  },

  stopover: {
    type: String,
    trim: true,
    default: ''
  },

  travelerInfo: travelerInfoSchema,
  tripInfo: tripInfoSchema,
  flightInfo: flightInfoSchema,
  hotelInfo: hotelInfoSchema,
  cruiseInfo: cruiseInfoSchema,

  createdOn: {
    type: Date,
    default: Date.now,
    index: true
  }
});

/**
 * Compound Index
 *
 * Improves queries that retrieve a specific user's itineraries
 * by status and sort them by newest first.
 */
itinerarySchema.index({
  userEmail: 1,
  status: 1,
  createdOn: -1
});

module.exports = mongoose.model('Itinerary', itinerarySchema);