/**
 * Travlr Getaways
 * ---------------------------------------------------------
 * Trip Database Model
 *
 * Defines the MongoDB/Mongoose schema used to store
 * travel package information.
 *
 * Database Enhancement:
 * - Enforces validation rules for trip data
 * - Uses indexes to improve search performance
 * - Prevents incomplete records from being stored
 * - Supports efficient trip retrieval operations
 */

const mongoose = require('mongoose');

/**
 * Trip Schema
 *
 * Stores information about available travel packages.
 * These records are displayed to customers and managed
 * through the administrative interface.
 */
const tripSchema = new mongoose.Schema({

  /**
   * Unique trip identifier.
   * Frequently used for lookups and booking operations.
   */
  code: {
    type: String,
    required: true,
    trim: true,
    uppercase: true,
    index: true
  },

  /**
   * Display name of the travel package.
   */
  name: {
    type: String,
    required: true,
    trim: true,
    index: true
  },

  /**
   * Duration of the trip.
   * Example: "7 Nights"
   */
  length: {
    type: String,
    required: true,
    trim: true
  },

  /**
   * Departure date.
   */
  start: {
    type: Date,
    required: true
  },

  /**
   * Resort or destination property.
   */
  resort: {
    type: String,
    required: true,
    trim: true
  },

  /**
   * Price per traveler.
   * Stored as a formatted string to maintain
   * compatibility with the existing application.
   */
  perPerson: {
    type: String,
    required: true,
    trim: true
  },

  /**
   * Image path used by the customer-facing site.
   */
  image: {
    type: String,
    required: true,
    trim: true
  },

  /**
   * Detailed trip description.
   */
  description: {
    type: String,
    required: true,
    trim: true
  }

},
{
  timestamps: true
});

/**
 * Compound Index
 *
 * Improves administrative searches and trip retrieval.
 */
tripSchema.index({
  code: 1,
  name: 1
});

const Trip = mongoose.model('trips', tripSchema);

module.exports = Trip;