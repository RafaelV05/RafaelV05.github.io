const tripsEndpoint = 'http://localhost:3000/api/trips';

const options = {
  method: 'GET',
  headers: {
    'Accept': 'application/json'
  }
};

// GET travel view
const travel = async (req, res) => {
  await fetch(tripsEndpoint, options)
    .then(res => res.json())
    .then(json => {

      let message = null;

      // Check if response is valid
      if (!(json instanceof Array)) {
        message = "API lookup error";
      } else {
        // Check if array is empty
        if (!json.length) {
          message = "No trips exist in our database!";
        }
      }

      res.render('travel', {
        title: 'Travlr Getaways',
        trips: json,
        message,
        travel: 'selected',
        travelActive: 'active'
      });
    })
    .catch(err => res.status(500).send(err.message));
};

module.exports = {
  travel
};