const axios = require('axios');

const index = (req, res) => {
  res.render('index', {
    title: 'Travlr Getaways',
    home: 'selected',
    homeActive: 'active'
  });
};

// Login page
const login = (req, res) => {
  res.render('login', {
    title: 'Login'
  });
};

// Register page
const register = (req, res) => {
  res.render('register', {
    title: 'Register'
  });
};

// Process Login
const doLogin = async (req, res) => {
  try {
    const response = await axios.post(
      'http://localhost:3000/api/login',
      {
        email: req.body.email,
        password: req.body.password
      }
    );

    res.cookie('token', response.data.token, { httpOnly: true });

    res.redirect('/');
  } catch (err) {
    res.redirect('/login');
  }
};

// Process Register
const doRegister = async (req, res) => {
  try {
    const response = await axios.post(
      'http://localhost:3000/api/register',
      {
        name: req.body.name,
        email: req.body.email,
        password: req.body.password
      }
    );

    res.cookie('token', response.data.token, { httpOnly: true });

    res.redirect('/');
  } catch (err) {
    res.redirect('/register');
  }
};

// Logout
const logout = (req, res) => {
  res.clearCookie('token');
  res.redirect('/');
};

// Itinerary
const itinerary = async (req, res) => {
  try {
    const token = req.cookies.token;

    if (!token) {
      return res.redirect('/login');
    }

    const response = await axios.get(
      'http://localhost:3000/api/itinerary',
      {
        headers: {
          Authorization: `Bearer ${token}`
        }
      }
    );

    const formattedTrips = response.data.map(trip => ({
      ...trip,
      createdOn: new Date(trip.createdOn).toLocaleDateString(
        'en-US',
        {
          year: 'numeric',
          month: 'long',
          day: 'numeric'
        }
      )
    }));

    res.render('itinerary', {
      title: 'My Itinerary',
      itineraries: formattedTrips
    });
  } catch (err) {
    console.log(err.message);

    res.render('itinerary', {
      title: 'My Itinerary',
      itineraries: []
    });
  }
};

// Reservations
const reservations = async (req, res) => {
  try {
    const token = req.cookies.token;

    if (!token) {
      return res.redirect('/login');
    }

    const response = await axios.get(
      'http://localhost:3000/api/itinerary',
      {
        headers: {
          Authorization: `Bearer ${token}`
        }
      }
    );

    const reservationsList = response.data.map(trip => ({
      ...trip,
      createdOn: new Date(trip.createdOn).toLocaleDateString(
        'en-US',
        {
          year: 'numeric',
          month: 'long',
          day: 'numeric'
        }
      ),
    }));

    res.render('reservations', {
      title: 'Reservations',
      reservations: reservationsList
    });

  } catch (err) {
    res.render('reservations', {
      title: 'Reservations',
      reservations: []
    });
  }
};

// News
const news = (req, res) => {
  res.render('news', {
    title: 'News'
  });
};

// Admin
const admin = async (req, res) => {
  try {
    const token = req.cookies.token;

    const response = await axios.get(
      'http://localhost:3000/api/admin/bookings',
      {
        headers: {
          Authorization: `Bearer ${token}`
        }
      }
    );

    const bookings = response.data.map(booking => ({
      ...booking,
      createdOn: new Date(
        booking.createdOn
      ).toLocaleDateString(
        'en-US',
        {
          year: 'numeric',
          month: 'long',
          day: 'numeric'
        }
      )
    }));

    res.render('admin', {
      title: 'Admin',
      bookings
    });

  } catch(err) {

    res.render('admin', {
      title: 'Admin',
      bookings: []
    });

  }
};
const adminDeleteBooking = async (req,res) => {

  try {

    const token = req.cookies.token;

    await axios.delete(
      `http://localhost:3000/api/admin/bookings/${req.params.id}`,
      {
        headers: {
          Authorization: `Bearer ${token}`
        }
      }
    );

    res.redirect('/admin');

  } catch(err) {

    res.redirect('/admin');

  }
};

const adminToggleStatus = async (req,res) => {

  try {

    const token = req.cookies.token;

    await axios.put(
      `http://localhost:3000/api/admin/bookings/${req.params.id}`,
      {
        status: req.body.status
      },
      {
        headers:{
          Authorization:`Bearer ${token}`
        }
      }
    );

    res.redirect('/admin');

  } catch(err){

    res.redirect('/admin');

  }
};

// Checkout
const checkout = async (req, res) => {
  try {
    const token = req.cookies.token;

    if (!token) {
      return res.redirect('/login');
    }

    const response = await axios.get(
      'http://localhost:3000/api/itinerary',
      {
        headers: {
          Authorization: `Bearer ${token}`
        }
      }
    );

    const pendingTrips =
      response.data.filter(
        t => t.status === 'Pending'
      );

    const total =
      pendingTrips.reduce(
        (sum, trip) => sum + trip.totalPrice,
        0
      );

    res.render('checkout', {
      title: 'Checkout',
      trips: pendingTrips,
      total
    });

  } catch (err) {

    res.render('checkout', {
      title: 'Checkout',
      trips: [],
      total: 0
    });
  }
};

const confirmCheckout = async (req, res) => {
  try {
    const token = req.cookies.token;

    await axios.put(
      'http://localhost:3000/api/itinerary/confirm',
      {},
      {
        headers: {
          Authorization: `Bearer ${token}`
        }
      }
    );

    res.redirect('/reservations');

  } catch(err) {
    res.redirect('/checkout');
  }
};

const removeCheckoutTrip = async (req, res) => {
  try {
    const token = req.cookies.token;

    await axios.delete(
      `http://localhost:3000/api/itinerary/pending/${req.params.id}`,
      {
        headers: {
          Authorization: `Bearer ${token}`
        }
      }
    );

    res.redirect('/checkout');

  } catch(err) {
    res.redirect('/checkout');
  }
};

// Book Itinerary
const bookItinerary = async (req, res) => {
  try {
    const token = req.cookies.token;

    if (!token) {
      return res.redirect('/login');
    }

    await axios.post(
      'http://localhost:3000/api/itinerary/book',
      {
        tripCode: req.body.tripCode
      },
      {
        headers: {
          Authorization: `Bearer ${token}`
        }
      }
    );

    res.redirect('/itinerary');
  } catch (err) {
    res.redirect('/travel');
  }
};



module.exports = {
  index,
  login,
  register,
  doLogin,
  doRegister,
  logout,
  itinerary,
  bookItinerary,
  removeCheckoutTrip,
  confirmCheckout,
  reservations,
  news,
  admin,
  adminDeleteBooking,
  adminToggleStatus,
  checkout
};