var express = require('express');
var router = express.Router();

const ctrlMain = require('../controllers/main');

function requireAdmin(req, res, next) {
  if (!res.locals.isLoggedIn) {
    return res.redirect('/login');
  }

  if (!res.locals.isAdmin) {
    return res.redirect('/');
  }

  next();
}

// Home
router.get('/', ctrlMain.index);

// Customer pages
router.get('/login', ctrlMain.login);
router.post('/login', ctrlMain.doLogin);

router.get('/register', ctrlMain.register);
router.post('/register', ctrlMain.doRegister);

router.get('/logout', ctrlMain.logout);

router.get('/itinerary', ctrlMain.itinerary);
router.post('/itinerary/book', ctrlMain.bookItinerary);

router.get('/reservations', ctrlMain.reservations);
router.get('/news', ctrlMain.news);

router.get('/admin', requireAdmin, ctrlMain.admin);
router.post('/admin/bookings/delete/:id', requireAdmin, ctrlMain.adminDeleteBooking);
router.post('/admin/bookings/status/:id', requireAdmin, ctrlMain.adminToggleStatus);

router.get('/checkout', ctrlMain.checkout);
router.post('/checkout/remove/:id', ctrlMain.removeCheckoutTrip);
router.post('/checkout/confirm', ctrlMain.confirmCheckout);

module.exports = router;