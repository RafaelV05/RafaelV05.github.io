/**
 * Travlr Getaways
 * ---------------------------------------------------------
 * Travel Agent Controller
 *
 * Handles customer booking operations, itinerary management,
 * checkout confirmation, and administrative booking actions.
 */

const Itinerary = require('../models/itinerary');
const Trip = require('../models/travlr');
const { sendError } = require('../utils/apiResponse');

/**
 * Creates a pending itinerary from a selected travel package.
 */
const bookPackage = async (req, res) => {
  try {
    const trip = await Trip.findOne({
      code: req.body.tripCode
    });

    if (!trip) {
      return sendError(res, 404, 'Trip not found');
    }

    // Convert formatted price string into a number.
    const price = parseFloat(
      trip.perPerson.replace(/[^0-9.]/g, '')
    );

    // Build a pending itinerary for the authenticated customer.
    const itinerary = new Itinerary({
      userEmail: req.auth.email,
      status: 'Pending',
      totalPrice: price,

      travelerInfo: {
        origin: 'Salt Lake City',
        destination: trip.name,
        departing_date: new Date(),
        returning_date: new Date()
      },

      tripInfo: {
        companionNum: 1
      },

      hotelInfo: {
        name: trip.resort,
        star: 4,
        location: trip.name,
        roomsRequested: 1,
        price: price
      }
    });

    await itinerary.save();

    res.status(201).json(itinerary);

  } catch (err) {
    sendError(res, 400, 'Unable to book trip', err);
  }
};

/**
 * Retrieves all itineraries for the authenticated customer.
 */
const getItinerary = async (req, res) => {
  try {
    const itineraries = await Itinerary.find({
      userEmail: req.auth.email
    });

    res.status(200).json(itineraries);

  } catch (err) {
    sendError(res, 400, 'Unable to retrieve itinerary', err);
  }
};

/**
 * Removes a pending trip from the customer's checkout list.
 */
const removePendingTrip = async (req, res) => {
  try {
    await Itinerary.deleteOne({
      _id: req.params.id,
      userEmail: req.auth.email,
      status: 'Pending'
    });

    res.status(200).json({
      message: 'Pending trip removed'
    });

  } catch (err) {
    sendError(res, 400, 'Unable to remove pending trip', err);
  }
};

/**
 * Confirms all pending trips for the authenticated customer.
 */
const confirmPendingTrips = async (req, res) => {
  try {
    await Itinerary.updateMany(
      {
        userEmail: req.auth.email,
        status: 'Pending'
      },
      {
        status: 'Confirmed'
      }
    );

    res.status(200).json({
      message: 'Trips confirmed'
    });

  } catch (err) {
    sendError(res, 400, 'Unable to confirm trips', err);
  }
};

/**
 * Admin function.
 *
 * Retrieves all customer bookings sorted by newest first.
 * Admin authorization is handled by route middleware.
 */
const getAllBookings = async (req, res) => {
  try {
    const bookings = await Itinerary.find().sort({
      createdOn: -1
    });

    res.status(200).json(bookings);

  } catch (err) {
    sendError(res, 400, 'Unable to retrieve bookings', err);
  }
};

/**
 * Admin function.
 *
 * Deletes a booking from the database.
 * Admin authorization is handled by route middleware.
 */
const deleteBooking = async (req, res) => {
  try {
    await Itinerary.deleteOne({
      _id: req.params.id
    });

    res.status(200).json({
      message: 'Booking deleted'
    });

  } catch (err) {
    sendError(res, 400, 'Unable to delete booking', err);
  }
};

/**
 * Admin function.
 *
 * Updates the status of a selected booking.
 * Admin authorization is handled by route middleware.
 */
const updateBookingStatus = async (req, res) => {
  try {
    await Itinerary.findByIdAndUpdate(
      req.params.id,
      {
        status: req.body.status
      }
    );

    res.status(200).json({
      message: 'Booking updated'
    });

  } catch (err) {
    sendError(res, 400, 'Unable to update booking', err);
  }
};

module.exports = {
  bookPackage,
  getItinerary,
  removePendingTrip,
  confirmPendingTrips,
  getAllBookings,
  deleteBooking,
  updateBookingStatus
};