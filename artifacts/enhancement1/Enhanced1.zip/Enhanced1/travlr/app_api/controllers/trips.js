/**
 * Travlr Getaways
 * ---------------------------------------------------------
 * Trips Controller
 *
 * Handles CRUD operations for travel packages used by both
 * the customer-facing site and the Angular admin interface.
 *
 * This controller supports:
 * - Retrieving all trips
 * - Retrieving one trip by trip code
 * - Creating new trips
 * - Updating existing trips
 * - Deleting trips
 */

const mongoose = require('mongoose');
require('../models/travlr');

const Model = mongoose.model('trips');
const { sendError } = require('../utils/apiResponse');

/**
 * GET: /trips
 *
 * Retrieves all available travel packages from MongoDB.
 */
const tripsList = async (req, res) => {
  try {
    const trips = await Model
      .find({})
      .exec();

    if (!trips || trips.length === 0) {
      return sendError(res, 404, 'No trips found');
    }

    return res.status(200).json(trips);

  } catch (err) {
    return sendError(res, 500, 'Unable to retrieve trips', err);
  }
};

/**
 * GET: /trips/:tripCode
 *
 * Retrieves one travel package using its unique trip code.
 */
const tripsFindByCode = async (req, res) => {
  try {
    const trip = await Model
      .findOne({ code: req.params.tripCode })
      .exec();

    if (!trip) {
      return sendError(res, 404, 'Trip not found');
    }

    return res.status(200).json(trip);

  } catch (err) {
    return sendError(res, 500, 'Unable to retrieve trip', err);
  }
};

/**
 * POST: /trips
 *
 * Creates a new travel package. This route is protected
 * and intended for authenticated administrative users.
 */
const tripsAddTrip = async (req, res) => {
  try {
    const body = req.body;

    const tripObj = {
      code: body.code,
      name: body.name,
      length: body.length,
      start: body.start,
      resort: body.resort,
      perPerson: body.perPerson,
      image: body.image,
      description: body.description
    };

    const trip = await Model.create(tripObj);

    if (!trip) {
      return sendError(res, 400, 'Unable to create trip');
    }

    return res.status(201).json(trip);

  } catch (err) {
    return sendError(res, 400, 'Unable to create trip', err);
  }
};

/**
 * PUT: /trips/:tripCode
 *
 * Updates an existing travel package by matching its
 * unique trip code.
 */
const tripsUpdateTrip = async (req, res) => {
  try {
    const trip = await Model
      .findOneAndUpdate(
        { code: req.params.tripCode },
        {
          code: req.body.code,
          name: req.body.name,
          length: req.body.length,
          start: req.body.start,
          resort: req.body.resort,
          perPerson: req.body.perPerson,
          image: req.body.image,
          description: req.body.description
        },
        { new: true }
      )
      .exec();

    if (!trip) {
      return sendError(res, 404, 'Trip not found');
    }

    return res.status(200).json(trip);

  } catch (err) {
    return sendError(res, 400, 'Unable to update trip', err);
  }
};

/**
 * DELETE: /trips/:tripCode
 *
 * Deletes a travel package by matching its unique trip code.
 */
const tripsDeleteTrip = async (req, res) => {
  try {
    const trip = await Model
      .findOneAndDelete({ code: req.params.tripCode })
      .exec();

    if (!trip) {
      return sendError(res, 404, 'Trip not found');
    }

    return res.status(200).json({
      message: 'Trip deleted successfully'
    });

  } catch (err) {
    return sendError(res, 400, 'Unable to delete trip', err);
  }
};

module.exports = {
  tripsList,
  tripsFindByCode,
  tripsAddTrip,
  tripsUpdateTrip,
  tripsDeleteTrip
};